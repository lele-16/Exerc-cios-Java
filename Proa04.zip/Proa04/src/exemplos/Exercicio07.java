package exemplos;
import java.util.Scanner;

public class Exercicio07 {
public static void main (String[]args){
	Scanner sc= new Scanner (System.in);
	System.out.println("Digite quantos anos voc� tem");
	int anos = sc.nextInt();
	System.out.println("Digite quantos meses nfaz o seu �ltimo anivers�rio");
int meses = sc.nextInt();

}
}
