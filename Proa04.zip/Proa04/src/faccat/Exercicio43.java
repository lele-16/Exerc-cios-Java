package faccat;

public class Exercicio43 {
	public static void main(String[] args) {
        int contador = 0;
        int numero = 101;

        while (contador < 10) {
            System.out.println(numero);
            numero++;
            contador++;
        }
    }
}
