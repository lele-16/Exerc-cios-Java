package faccat;

public class Exemplo01 {
public static void main(String[]args) {//est� sendo criada uma a��o
	System.out.println("Equipe 04");
}
}
